import { TypeOrmModuleOptions } from '@nestjs/typeorm';
export declare const getTypeOrmConfig: () => Promise<TypeOrmModuleOptions>;
