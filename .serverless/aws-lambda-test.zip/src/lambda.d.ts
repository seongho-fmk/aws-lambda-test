import { APIGatewayProxyEvent, Context } from 'aws-lambda';
export declare const handler: (event: APIGatewayProxyEvent, context: Context) => Promise<import("aws-serverless-express").Response>;
